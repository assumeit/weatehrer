import React, { useState, useEffect } from 'react';
import axios from 'axios';
import WeatherContainer from './WeatherContainer';
import SearchBar from './SearchBar';
import './App.css';

const API_KEY = 'c7e724680feece21eb746b88636fc344';

function App() {
  const [weatherData, setWeatherData] = useState([]);
  const [location, setLocation] = useState('');
  const [background, setBackground] = useState('default');
  const [searched, setSearched] = useState(false);  // Track if a search is made

  const cities = ['New York', 'Tokyo', 'London', 'Paris', 'Sydney', 'Mumbai'];

  const fetchWeather = async (location) => {
    try {
      const res = await axios.get(
        `https://api.openweathermap.org/data/2.5/weather?q=${location}&appid=${API_KEY}&units=metric`
      );
      setWeatherData([res.data]);
      setBackground(res.data.weather[0].main.toLowerCase());
      setSearched(true);  // Set searched flag
    } catch (error) {
      console.error("Error fetching weather data", error);
    }
  };

  const fetchMultipleWeather = async () => {
    try {
      const promises = cities
        .sort(() => 0.5 - Math.random())
        .slice(0, 3)
        .map(city => axios.get(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`));

      const results = await Promise.all(promises);
      setWeatherData(results.map(res => res.data));
      setBackground('default');
      setSearched(false);  // Reset search flag
    } catch (error) {
      console.error("Error fetching multiple weather data", error);
    }
  };

  useEffect(() => {
    fetchMultipleWeather();
  }, []);

  return (
    <div className={`app-container ${background}`}>
      <div className="header">
        <h1></h1>
        <SearchBar onSearch={fetchWeather} setLocation={setLocation} location={location} />
      </div>
      <WeatherContainer weatherData={weatherData} searched={searched} />
    </div>
  );
}

export default App;
