import React from 'react';
import './SearchBar.css';

const SearchBar = ({ onSearch, setLocation, location }) => {
  const handleSubmit = (e) => {
    e.preventDefault();
    if (location.trim()) {
      onSearch(location);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="search-bar">
      <input 
        type="text" 
        placeholder="Enter location" 
        value={location} 
        onChange={(e) => setLocation(e.target.value)}
      />
      <button type="submit" className="btn btn-primary">Get Weather</button>
    </form>
  );
};

export default SearchBar;
