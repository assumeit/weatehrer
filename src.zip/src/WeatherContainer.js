import React from 'react';
import './WeatherContainer.css';

const WeatherContainer = ({ weatherData, searched }) => {
  const formatDate = (timestamp) => {
    const date = new Date(timestamp * 1000);
    return date.toLocaleString();
  };

  return (
    <div className="container weather-container">
      {weatherData.map((weather, index) => (
        <div key={index} className="weather-card">
          <h2>{weather.name}</h2>
          <p>{formatDate(weather.dt)}</p>
          <img 
            src={`http://openweathermap.org/img/wn/${weather.weather[0].icon}@2x.png`} 
            alt={weather.weather[0].description} 
          />
          <p>{weather.weather[0].description}</p>
          <p>{Math.round(weather.main.temp)}°C</p>
          <p>Humidity: {weather.main.humidity}%</p>
        </div>
      ))}
    </div>
  );
};

export default WeatherContainer;
